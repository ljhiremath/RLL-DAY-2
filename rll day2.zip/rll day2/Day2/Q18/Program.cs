﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Q18
{
    class Program
    {
        static void Main(string[] args)
        {

            List<genEmployee> empList = new List<genEmployee>();
            for (int i = 0; i < 2; i++)
            {
                genEmployee objEmp = new genEmployee();
                objEmp.SetEmployeeDetails();
                empList.Add(objEmp);
            }

            foreach (genEmployee item in empList)
            {
                item.ShowEmployeeDetails();
            }



        }
    }
}
