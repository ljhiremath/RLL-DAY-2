﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Q19
{
    public partial class Form1 : Form
    {
        string sqlcon = @"Data Source=.;Initial Catalog=assignment;Integrated Security=True";
        string sqlcmd;
        SqlDataAdapter da;
        DataSet ds;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlcmd = "select * from  ProductDetails";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];


        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            sqlcmd="insert into ProductDetails values ("+txtID.Text+",'"+txtName.Text+"',"+txtunitPrice.Text+","+txtQuantity.Text+")";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
           

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            sqlcmd = "update ProductDetails set ProductName='" + txtName.Text + "', UnitPrice=" + txtunitPrice.Text + ", Quantity=" + txtQuantity.Text + " where ProductId="+txtID.Text+"";

            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            sqlcmd = "delete from  ProductDetails where ProductId=" + txtID.Text + "";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }
    }
}
