﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Q17
{
    class Program
    {
        static void Main(string[] args)
        {
          
            ArrayList empArrayList = new ArrayList();
            for (int i = 0; i < 2;i++ )
            {
                Employee objEmp = new Employee();
                objEmp.SetEmployeeDetails();
                empArrayList.Add(objEmp);
            }

            foreach (Employee item in empArrayList)
            {
                item.ShowEmployeeDetails();
            }



        }
    }
}
