﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q16
{
    class Swapping
    {
        public void Swap<S>(ref S leftVar,ref S rightVar) 
        {
            S temp;
            temp = leftVar;
            leftVar = rightVar;
            rightVar = temp;
            Console.WriteLine("Left Var = "+leftVar+" Right Var ="+rightVar);
        } 
        static void Main(string[] args)
        {
            Swapping objSwap = new Swapping();
            int a = 10,b=20;
            objSwap.Swap<int>(ref a,ref b);
            Swapping objSwapString = new Swapping();
            string str1 = "Wipro", str2 = "Hello";
            objSwapString.Swap<string>(ref str1, ref str2);
        }
    }
}
